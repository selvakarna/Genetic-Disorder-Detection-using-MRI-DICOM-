clc
clear all;
close all;
%% PRE-PROCESING
% TO BROWS MRI IMAGE
[MRI,path]=uigetfile('*.jpeg'); 
% TO READ IMAGE
MRI_RGB=imread(MRI);
% SHOW IAMGE
figure,subplot(121);imshow(MRI_RGB);
title('INPUT MRI IMAGE')
% CALCULATE IMAGE DIMENTIONS
DIM=ndims(MRI_RGB);
% CONVERT A COLOR INTO GRAY
% 
if DIM==3;
    GRY=rgb2gray(MRI_RGB);
    GRY=im2double(GRY);
else DIM==2;
    GRY=im2double(MRI_RGB);
end
% CALCULATE SIZE OF IMAGE
SIZ=size(GRY);
SUM=sum(SIZ);
PRO=2*DIM;
MAT=SUM/PRO;
% APPLY LOGARATHAMIC 
% CALCULATE IMAGE SIZE AND RESIZE IMAGE
LOG_MAT=log(MAT);
NEW=LOG_MAT;
if NEW==4.4466   || NEW==5.1397 
GRY=GRY;
else
    GRY=imresize(GRY,[256 256]);
end
subplot(122);imshow( GRY);
title('RESIZED MRI IMAGE');
%  LAYERS EXTRACTION PROCESS
% EXTRACT RED LAYER FROM RGB
RED_LYR=MRI_RGB(:,:,1);
% EXTRACT GREEN LAYER FROM RGB
GREN_LYR=MRI_RGB(:,:,2);
% EXTRACT BLUE LAYER FROM RGB
BLU_LYR=MRI_RGB(:,:,3);
% SHOW ALL LAYERS
figure,subplot(221);imshow(MRI_RGB);
title('RGB IMAGE');
subplot(222);imshow(RED_LYR);
title('RED LAYER IMAGE');
subplot(223);imshow(GREN_LYR);
title('GREEN LAYER IMAGE');
subplot(224);imshow(BLU_LYR);
title('BLUE LAYER IMAGE');

%% COMPUTE IMAGE % APPLY INTEGRAL FILTER
IMAGE = GRY;
INT_IMG = integralImag1(IMAGE);
% APPLY IMAGE BBOX AND WEIGHTS
BOUND_FEA=[1 1 6 6];
WGT=1/19;


%% FILTER   

IMAGE=GRY;
[SYM_FILTR,REP_FILTR,CIR_FILTR,FILTR]=MULTI_DIM_FILTER(IMAGE);
%% 

IMG=FILTER_SELECTION(SYM_FILTR,REP_FILTR,CIR_FILTR,FILTR);

ITER =4;    
DELTA= 1/7;                  
KAPPA =30;
OPTION = 2; 
DIFF_IMG = ANISTROFFIC_DIFFUSION(IMG, ITER, DELTA, KAPPA, OPTION);
figure,imshow(DIFF_IMG);
%% QUANTITATIVE SUSCEPTIBILITY  QS MAPPING PROCESS
%  L1 QSM
% rho =0.857
I=DIFF_IMG ;
I=im2bw(I,0.5);
figure,subplot(231);imshow(I);
title('Binary image');
[junk threshold] = edge(I,'canny');
fudgeFactor = .9;
be_im = edge(I,'prewitt'); %%%%
% figure, imshow(be_im), 
% title('binary gradient mask');
ang1 = strel('line', 2, 120); %%
ang2 = strel('line',2, 145); %%
%%%BACKGROUND MASKING 
dil_im = imdilate(be_im, [ang1 ang2 ]);  
subplot(232); imshow(dil_im ), 
title('dilated gradient mask');
%%%BINARY MASKING % SUSCEPTIBILTY ESTIMATION
bin_hol = imfill(dil_im , 'holes');  %%
subplot(233)
imshow(bin_hol);
title('binary image with filled holes');
%%%SUBRESSING PROCESS
sub_im = imclearborder(bin_hol, 8); %%
subplot(234)
imshow(sub_im),
title('cleared border image');
Mor_op = strel('diamond',3);  %%%%%
%%%MAP DATA BY USING EROSTION PROCESS
ero_im= imerode(sub_im,Mor_op); %%%%%%%


tic
p=(DIFF_IMG +ero_im);
% C = corner(ero_im);
C = cornermetric(ero_im);

subplot(235)
imshow(p);
title('MAPPED REGION');
hold on
plot(C(:,1), C(:,2), 'c*');
%% 
LEVL1=imcrop(p,[72.5 64.5 115 86]);
subplot(236)
imshow(LEVL1);
title('REGION');
hold off;
I =p;
figure,imshow(I);
hold on
ALZMR=[86, 63, 83, 77];
rectangle('Position',ALZMR,'EdgeColor','y');
title('L1 QSM MAPPED IMAGE');
%% FEATURES EXTRACTION  PROCESS
%  FEATURES CALCULATION FROM QSM DATAS
% 
FEA_DAT=LEVL1;
% IMAGE STD DEVOATION CALCULATION
STD_FEA=std2(LEVL1);
% IMAGE MEAN CALCULATION
MEAN_FEA=mean2(LEVL1);
%  VARIANCE CALCULATION
VAR_FEA=var(double(LEVL1));
VAR_FEA=abs(VAR_FEA);
VAR_FEA=max(VAR_FEA)/1e3;
FEATURES.STD_FEA=STD_FEA;
FEATURES.MEAN_FEA=MEAN_FEA;
FEATURES.VAR_FEA=VAR_FEA/1e3;


 
